(function () {
  "use strict";

  // n8n production webhook for the GitHub Code Reviewer workflow.
  const WEBHOOK_URL = "http://localhost:5678/webhook/GITHUB_reviewer1";

  const repoCard = document.querySelector(".repo-card");
  const repoInput = document.getElementById("repoUrl");
  const reviewBtn = document.getElementById("reviewBtn");
  const resultBody = document.getElementById("resultBody");

  function setWaitingState() {
    resultBody.classList.remove("has-error");
    resultBody.innerHTML =
      '<div class="placeholder-state">' +
      '<span class="pulse-dot" aria-hidden="true"></span>' +
      "<p>Waiting for review...</p>" +
      "</div>";
  }

  function setValidationMessage(message) {
    resultBody.classList.add("has-error");
    resultBody.innerHTML =
      '<div class="placeholder-state state-error">' +
      '<p>' + message + '</p>' +
      "</div>";
  }

  function setLoadingState() {
    resultBody.classList.remove("has-error");
    resultBody.innerHTML =
      '<div class="placeholder-state">' +
      '<span class="loader-ring" aria-hidden="true"></span>' +
      "<p>Analyzing your code, please wait...</p>" +
      "</div>";
  }

  function setErrorState(message) {
    resultBody.classList.add("has-error");
    resultBody.innerHTML =
      '<div class="placeholder-state state-error">' +
      '<p>' + message + '</p>' +
      "</div>";
  }

  function renderReview(text) {
    resultBody.classList.remove("has-error");
    const pre = document.createElement("pre");
    pre.className = "review-text";
    pre.textContent = text;
    resultBody.innerHTML = "";
    resultBody.appendChild(pre);
  }

  // n8n / the LLM may return the review as plain text, as JSON like
  // { "review": "..." }, or nested in an array — unwrap whichever shows up.
  function extractReviewText(data) {
    if (typeof data === "string") return data;
    if (Array.isArray(data)) return extractReviewText(data[0]);
    if (data && typeof data === "object") {
      return (
        data.review ||
        data.text ||
        data.output ||
        data.message ||
        JSON.stringify(data, null, 2)
      );
    }
    return String(data);
  }

  async function handleReview() {
    const url = repoInput.value.trim();
    repoInput.classList.remove("input-error");

    if (!url) {
      repoInput.classList.add("input-error");
      setValidationMessage("Please enter a GitHub file or repository URL before starting a review.");
      repoCard.classList.remove("shake");
      void repoCard.offsetWidth;
      repoCard.classList.add("shake");
      return;
    }

    const originalLabel = reviewBtn.textContent;
    reviewBtn.disabled = true;
    repoInput.disabled = true;
    reviewBtn.textContent = "Reviewing...";
    setLoadingState();

    try {
      const response = await fetch(WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ githubUrl: url }),
      });

      if (!response.ok) {
        throw new Error("Server responded with status " + response.status);
      }

      const contentType = response.headers.get("content-type") || "";
      const raw = contentType.includes("application/json")
        ? await response.json()
        : await response.text();

      renderReview(extractReviewText(raw));
    } catch (err) {
      console.error("Code review request failed:", err);
      setErrorState(
        "Something went wrong while contacting the AI reviewer. Please confirm the n8n workflow is active and try again."
      );
    } finally {
      reviewBtn.disabled = false;
      repoInput.disabled = false;
      reviewBtn.textContent = originalLabel;
    }
  }

  reviewBtn.addEventListener("click", handleReview);
  repoInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault();
      handleReview();
    }
  });
  repoInput.addEventListener("input", function () {
    repoInput.classList.remove("input-error");
  });

  setWaitingState();
})();
